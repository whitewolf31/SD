#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>

#include "bst_node.h"
#include "helpers.h"

size_t tree_height(bst_node_t * const root) {
  return -1;
}

size_t node_height(bst_node_t * const node) {
  return -1;
}
