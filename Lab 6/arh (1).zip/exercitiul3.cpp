#include "helpers.h"
#include "bst_node.h"

void traverse_in_order(bst_node_t * const root, func_t func) {
}

void traverse_pre_order(bst_node_t * const root, func_t func) {
}

void traverse_post_order(bst_node_t * const root, func_t func) {
}
