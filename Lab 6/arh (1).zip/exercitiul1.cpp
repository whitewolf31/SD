#include "helpers.h"
#include "bst_node.h"

void insert(bst_node_t **root_ptr, const double value) {

}

bst_node_t *search(bst_node_t * const root, const double value) {
  return NULL;
}

void remove(bst_node_t **root_ptr, const double value) {

}
