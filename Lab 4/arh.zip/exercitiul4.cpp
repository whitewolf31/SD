#include <stdio.h>
#include <stdlib.h>

#include "list.h"

size_t remove_equal_sequence(node_t *&begin, node_t *end, node_func_t func) {
  return 0;
}
