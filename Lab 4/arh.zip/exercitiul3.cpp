#include "helpers.h"
#include "list.h"

void apply(node_t *begin, node_t *end, node_func_t func) {
}
