#include <stdio.h>
#include <stdlib.h>

#include "list.h"

void remove(node_t *&node) {
}

node_t *nth_element( node_t *const head, const size_t nth) {
  return NULL;
}
