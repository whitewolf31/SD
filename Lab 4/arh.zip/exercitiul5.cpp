#include <stdio.h>
#include <stdlib.h>

#include "list.h"

void swap_with_neighbour(node_t *current, node_t *left,
                        node_t *up, node_t *right,
                        node_t *down, enum direction dir) {
}
