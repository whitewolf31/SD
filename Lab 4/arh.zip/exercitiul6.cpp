#include <stdlib.h>
#include <stdio.h>

#include "helpers.h"
#include "list.h"

void insert_circular(node_t **head, node_t *node) {
}
