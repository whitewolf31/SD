#include <stdlib.h>
#include <stdio.h>

#include "helpers.h"
#include "list.h"

node_t *middle(node_t *node) {
  return NULL;
}

node_t *index(node_t* node, int index) {
  return NULL;
}
