#include <stdio.h>
#include <stdlib.h>

#include "list.h"


void insert_sorted(node_t **node, double data, compare_t cmp) {
}

node_t *merge_sorted(node_t **node1, node_t **node2, compare_t cmp) {
  return NULL;
}
